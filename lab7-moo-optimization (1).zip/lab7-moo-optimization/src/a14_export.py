# %% [markdown]
# # Raw results export
# Writes every raw number behind the tables and plots to `results/` (CSV): per-run metrics, obtained fronts and decision vectors, per-seed head-to-head and sensitivity results.

# %%
import os, csv, json
RD = 'results'; os.makedirs(RD + '/fronts', exist_ok=True); os.makedirs(RD + '/per_seed', exist_ok=True)
def wcsv(path, header, rows):
    with open(path, 'w', newline='') as f: w = csv.writer(f); w.writerow(header); w.writerows(rows)
# 1. implementation-log metrics: one row per (algorithm, problem) run, seed 0
wcsv(RD + '/metrics_per_run_seed0.csv', ['alg_no', 'algorithm', 'problem', 'n_points', 'HV', 'IGD', 'Spacing', 'time_s', 'nfe', 'status'],
     [[no, NAMES.get(no, ''), k, v['n'], v['hv'], v['igd'], v['sp'], v['time'], v['nfe'], v['status']] for (no, k), v in sorted(RES.items(), key=lambda t: (t[0][0], t[0][1]))])
# 2. obtained fronts (objective values) and decision vectors
for (no, k), F in FRONTS.items():
    np.savetxt(f"{RD}/fronts/alg{no:02d}_{k}_objectives.csv", np.atleast_2d(F), delimiter=',', header=','.join(f'f{i+1}' for i in range(np.atleast_2d(F).shape[1])), comments='')
    if (no, k) in XFR: X = np.atleast_2d(XFR[(no, k)]); np.savetxt(f"{RD}/fronts/alg{no:02d}_{k}_decision.csv", X, delimiter=',', header=','.join(f'x{i+1}' for i in range(X.shape[1])), comments='')
# 3. reference (true) fronts
for k, P in PROB.items():
    if P.Z is not None: np.savetxt(f"{RD}/fronts/reference_{k}.csv", P.Z, delimiter=',', header=','.join(f'f{i+1}' for i in range(P.Z.shape[1])), comments='')
# 4. per-seed results of the head-to-head (D.1, D.2) and the sensitivity studies (C.3)
def per_seed(name, out, key):
    rows = [[a, s, r[1]['n'], r[1]['hv'], r[1]['igd'], r[1]['sp'], r[2]] for a, lst in out.items() for s, r in zip(SEEDS, lst)]
    wcsv(f"{RD}/per_seed/{name}.csv", ['algorithm_or_value', 'seed', 'n_points', 'HV', 'IGD', 'Spacing', 'time_s'], rows)
    for a, lst in out.items():
        for s, r in zip(SEEDS, lst): np.savetxt(f"{RD}/fronts/{name}_{str(a).replace('/', '-')}_seed{s}.csv", r[0], delimiter=',', header=','.join(f'f{i+1}' for i in range(r[0].shape[1])), comments='')
per_seed('D1_P3', outD3, 'P3'); per_seed('D1_P5', outD5, 'P5'); per_seed('D2_P10_M5', outM, 'P10_5'); per_seed('C3_MOEAD_T_P3', outT, 'P3'); per_seed('C3_MOMA_pls_P5', outL, 'P5')
wcsv(RD + '/per_seed/D3_P8_tsp.csv', ['algorithm', 'budget', 'seed', 'n_points', 'time_s'], [[a, b, s, len(F), dt] for (a, b, s), (F, dt) in allF.items()])
for (a, b, s), (F, dt) in allF.items(): np.savetxt(f"{RD}/fronts/D3_P8_{a.replace('/', '-')}_b{b}_seed{s}.csv", F, delimiter=',', header='distance,time', comments='')
# 5. TOPSIS/VIKOR input and the problem-study numbers
wcsv(RD + '/D4_P4_front_points_risk_return.csv', ['risk', 'return'], D4.tolist())
def jsonable(o):
    if isinstance(o, dict): return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [jsonable(v) for v in o]
    if isinstance(o, np.ndarray): return o.tolist()
    if isinstance(o, (np.floating, np.integer)): return o.item()
    return o if isinstance(o, (int, float, str, bool, type(None))) else str(o)
json.dump(jsonable({k: v for k, v in STUDY.items() if k != 'E'}), open(RD + '/study_numbers.json', 'w'), indent=1)
print(len(os.listdir(RD + '/fronts')), 'front files written to', RD)
